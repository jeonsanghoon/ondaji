/**
 * 
 */
package com.mrc.framework;

/**
 * @author jsh
 *
 */
public class CommonInfo {
	public CommonInfo() {};
	public String getData() {
		return "common";
	}
}
