package com.mrc.db.dao;

import com.mrc.db.dto.member.member_cond;
import com.mrc.db.dto.member.t_member;

public interface IMemberDao<member_cond, t_member> extends IBaseDao<member_cond, t_member> {
	
}
