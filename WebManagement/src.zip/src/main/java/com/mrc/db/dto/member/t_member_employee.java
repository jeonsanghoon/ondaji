package com.mrc.db.dto.member;

import java.io.Serializable;

import lombok.Data;

@Data
public class t_member_employee implements Serializable{
	private String DEPT_NAME;
}
